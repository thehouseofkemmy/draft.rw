import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { format } from "date-fns";
import { toast } from "sonner";
import { Link } from "react-router-dom";
import { z } from "zod";

type Comment = {
  id: string;
  content: string;
  created_at: string;
  user_id: string;
  profiles: { display_name: string | null; avatar_url: string | null } | null;
};

const schema = z.string().trim().min(1, "Say something").max(2000, "Too long");

const Comments = ({ poemId }: { poemId: string }) => {
  const { user, isAdmin } = useAuth();
  const [list, setList] = useState<Comment[]>([]);
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(false);

  const load = async () => {
    const { data: rows } = await supabase
      .from("comments")
      .select("id, content, created_at, user_id")
      .eq("poem_id", poemId)
      .order("created_at", { ascending: false });
    if (!rows) { setList([]); return; }
    const ids = Array.from(new Set(rows.map((r) => r.user_id)));
    const { data: profs } = ids.length
      ? await supabase.from("profiles").select("id, display_name, avatar_url").in("id", ids)
      : { data: [] as any };
    const map = new Map((profs ?? []).map((p: any) => [p.id, p]));
    setList(
      rows.map((r) => ({
        ...r,
        profiles: (map.get(r.user_id) as any) ?? null,
      })) as Comment[]
    );
  };

  useEffect(() => { load(); /* eslint-disable-next-line */ }, [poemId]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    const parsed = schema.safeParse(text);
    if (!parsed.success) { toast.error(parsed.error.issues[0].message); return; }
    setLoading(true);
    const { error } = await supabase
      .from("comments")
      .insert({ poem_id: poemId, user_id: user.id, content: parsed.data });
    setLoading(false);
    if (error) { toast.error("Could not post comment."); return; }
    setText("");
    load();
  };

  const remove = async (id: string) => {
    await supabase.from("comments").delete().eq("id", id);
    load();
  };

  return (
    <section className="mt-16">
      <h3 className="label-mono mb-6">— Marginalia ({list.length})</h3>

      {user ? (
        <form onSubmit={submit} className="mb-10">
          <Textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="leave a thought…"
            maxLength={2000}
            rows={3}
            className="bg-paper border-rule font-serif italic text-base"
          />
          <div className="mt-3 flex justify-between items-center">
            <span className="label-mono">{text.length}/2000</span>
            <Button type="submit" disabled={loading} className="font-mono text-xs uppercase tracking-widest">
              {loading ? "…" : "Post"}
            </Button>
          </div>
        </form>
      ) : (
        <p className="font-serif italic text-ink-soft mb-10">
          <Link to="/auth" className="underline decoration-rule underline-offset-4 hover:text-primary">Sign in</Link> to leave a comment.
        </p>
      )}

      <ul className="space-y-8">
        {list.map((c) => (
          <li key={c.id} className="flex gap-4">
            <Avatar className="h-9 w-9 border border-rule">
              <AvatarImage src={c.profiles?.avatar_url ?? undefined} />
              <AvatarFallback className="text-xs font-mono">
                {(c.profiles?.display_name ?? "·").slice(0, 2).toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <div className="flex items-baseline gap-3">
                <span className="font-serif text-ink">{c.profiles?.display_name ?? "anonymous"}</span>
                <span className="label-mono">{format(new Date(c.created_at), "MMM d")}</span>
                {(user?.id === c.user_id || isAdmin) && (
                  <button onClick={() => remove(c.id)} className="label-mono hover:text-destructive">delete</button>
                )}
              </div>
              <p className="font-serif text-ink-soft mt-1 whitespace-pre-wrap">{c.content}</p>
            </div>
          </li>
        ))}
        {list.length === 0 && (
          <li className="font-serif italic text-ink-soft">no marginalia yet — be the first.</li>
        )}
      </ul>
    </section>
  );
};

export default Comments;