import { Link, NavLink, useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";

const Layout = ({ children }: { children: React.ReactNode }) => {
  const { user, isAdmin, signOut } = useAuth();
  const navigate = useNavigate();

  const navClass = ({ isActive }: { isActive: boolean }) =>
    `label-mono transition-colors hover:text-ink ${isActive ? "text-ink" : ""}`;

  return (
    <div className="relative min-h-screen flex flex-col bg-background text-foreground">
      <header className="relative z-10 border-b border-rule/60">
        <div className="max-w-3xl mx-auto px-6 py-6 flex items-center justify-between gap-6">
          <Link to="/" className="font-serif text-xl tracking-tight italic">
            drafts.rw<span className="text-primary">.</span>
          </Link>
          <nav className="flex items-center gap-6">
            <NavLink to="/" end className={navClass}>pieces</NavLink>
            <NavLink to="/about" className={navClass}>about</NavLink>
            {user && <NavLink to="/compose" className={navClass}>write</NavLink>}
            {isAdmin && <NavLink to="/admin" className={navClass}>studio</NavLink>}
            {user ? (
              <>
                <NavLink to="/profile" className={navClass}>profile</NavLink>
                <button onClick={async () => { await signOut(); navigate("/"); }} className="label-mono hover:text-ink">
                  sign out
                </button>
              </>
            ) : (
              <Link to="/auth" className="label-mono hover:text-ink">sign in</Link>
            )}
          </nav>
        </div>
      </header>

      <main className="relative z-10 flex-1">{children}</main>

      <footer className="relative z-10 border-t border-rule/60 mt-24">
        <div className="max-w-3xl mx-auto px-6 py-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <p className="label-mono">© {new Date().getFullYear()} drafts.rw — all rights reserved</p>
          <p className="font-serif italic text-ink-soft text-sm">
            "a quiet room for work that arrives when it is ready."
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Layout;
