import { useEffect, useState } from "react";
import { Heart } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";

const LikeButton = ({ poemId }: { poemId: string }) => {
  const { user } = useAuth();
  const [count, setCount] = useState(0);
  const [liked, setLiked] = useState(false);

  const refresh = async () => {
    const { count: c } = await supabase
      .from("likes")
      .select("*", { count: "exact", head: true })
      .eq("poem_id", poemId);
    setCount(c ?? 0);
    if (user) {
      const { data } = await supabase
        .from("likes")
        .select("id")
        .eq("poem_id", poemId)
        .eq("user_id", user.id)
        .maybeSingle();
      setLiked(!!data);
    } else setLiked(false);
  };

  useEffect(() => { refresh(); /* eslint-disable-next-line */ }, [poemId, user?.id]);

  const toggle = async () => {
    if (!user) { toast.error("Sign in to leave a heart."); return; }
    if (liked) {
      await supabase.from("likes").delete().eq("poem_id", poemId).eq("user_id", user.id);
    } else {
      await supabase.from("likes").insert({ poem_id: poemId, user_id: user.id });
    }
    refresh();
  };

  return (
    <button onClick={toggle} className="inline-flex items-center gap-2 label-mono hover:text-primary transition-colors">
      <Heart className={`w-4 h-4 ${liked ? "fill-primary text-primary" : ""}`} />
      <span>{count}</span>
    </button>
  );
};

export default LikeButton;