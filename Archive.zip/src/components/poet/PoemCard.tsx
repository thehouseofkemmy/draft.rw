import { Link } from "react-router-dom";
import { format } from "date-fns";

type Author = { id: string; display_name: string | null } | null;

type Props = {
  id: string;
  title: string;
  excerpt: string | null;
  content: string;
  created_at: string;
  author?: Author;
};

const PoemCard = ({ id, title, excerpt, content, created_at, author }: Props) => {
  const preview = excerpt || content.split("\n").slice(0, 4).join("\n");
  return (
    <article className="group border-b border-rule/60 pb-10">
      <Link to={`/poems/${id}`} className="block">
        <p className="label-mono mb-3">{format(new Date(created_at), "MMMM d, yyyy")}</p>
        <h2 className="font-serif text-3xl md:text-4xl text-ink mb-4 group-hover:text-primary transition-colors">
          {title}
        </h2>
        <p className="poem-body text-ink-soft line-clamp-4 italic">{preview}</p>
        <span className="label-mono mt-4 inline-block group-hover:text-primary transition-colors">
          read →
        </span>
      </Link>
      {author && (
        <Link
          to={`/poet/${author.id}`}
          className="label-mono mt-3 inline-block hover:text-primary transition-colors"
        >
          {author.display_name ?? "unnamed poet"}
        </Link>
      )}
    </article>
  );
};

export default PoemCard;
