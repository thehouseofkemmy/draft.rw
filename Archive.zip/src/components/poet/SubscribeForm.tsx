import { useState } from "react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";

const schema = z.object({
  email: z.string().trim().email("Enter a valid email").max(255),
});

const SubscribeForm = () => {
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = schema.safeParse({ email });
    if (!parsed.success) {
      toast.error(parsed.error.issues[0].message);
      return;
    }
    setLoading(true);
    const { error } = await supabase.from("subscribers").insert({ email: parsed.data.email });
    setLoading(false);
    if (error) {
      if (error.code === "23505") toast.success("You're already on the list — thank you.");
      else toast.error("Couldn't subscribe. Try again?");
      return;
    }
    toast.success("Subscribed. New pieces will find you.");
    setEmail("");
  };

  return (
    <form onSubmit={onSubmit} className="flex flex-col sm:flex-row gap-2 max-w-md">
      <Input
        type="email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        placeholder="your@email.com"
        className="bg-paper border-rule font-mono text-sm"
        maxLength={255}
        required
      />
      <Button type="submit" disabled={loading} variant="default" className="font-mono text-xs uppercase tracking-widest">
        {loading ? "..." : "Subscribe"}
      </Button>
    </form>
  );
};

export default SubscribeForm;