import Layout from "@/components/poet/Layout";

const About = () => (
  <Layout>
    <section className="max-w-2xl mx-auto px-6 pt-20 pb-24">
      <p className="label-mono mb-6">— colophon</p>
      <h1 className="font-serif text-5xl text-ink mb-10">about</h1>
      <div className="poem-body space-y-6 text-ink-soft">
        <p>drafts.rw is a shared room for poets, readers, and quiet work. it is a place for pieces
        that are still in motion, offered without schedule and received without rush.</p>
        <p>if you'd like to be told when a new piece arrives, leave your email on the home page.
        no algorithm. no pressure. just a letter when there is something to say.</p>
        <p className="italic">— drafts.rw</p>
      </div>
    </section>
  </Layout>
);

export default About;