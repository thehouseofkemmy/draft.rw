import { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import { useAuth } from "@/hooks/useAuth";
import Layout from "@/components/poet/Layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { z } from "zod";

const emailSchema = z.string().trim().email("Invalid email").max(255);
const pwSchema = z.string().min(8, "At least 8 characters").max(128);
const nameSchema = z.string().trim().min(1).max(60);

const Auth = () => {
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { user } = useAuth();

  useEffect(() => { if (user) navigate("/"); }, [user, navigate]);

  const onGoogle = async () => {
    setLoading(true);
    const result = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: window.location.origin,
    });
    if (result.error) {
      setLoading(false);
      return toast.error(result.error.message ?? "Google sign-in failed");
    }
    if (result.redirected) return;
    navigate("/");
  };

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const e1 = emailSchema.safeParse(email);
    const p1 = pwSchema.safeParse(password);
    if (!e1.success) return toast.error(e1.error.issues[0].message);
    if (!p1.success) return toast.error(p1.error.issues[0].message);
    setLoading(true);
    if (mode === "signup") {
      const n1 = nameSchema.safeParse(displayName);
      if (!n1.success) { setLoading(false); return toast.error("Pick a display name"); }
      const { error } = await supabase.auth.signUp({
        email: e1.data, password: p1.data,
        options: { emailRedirectTo: window.location.origin, data: { display_name: n1.data } },
      });
      setLoading(false);
      if (error) return toast.error(error.message);
      toast.success("Welcome.");
      navigate("/");
    } else {
      const { error } = await supabase.auth.signInWithPassword({ email: e1.data, password: p1.data });
      setLoading(false);
      if (error) return toast.error(error.message);
      navigate("/");
    }
  };

  return (
    <Layout>
      <section className="max-w-md mx-auto px-6 pt-20 pb-24">
        <p className="label-mono mb-6">— {mode === "signin" ? "return" : "arrive"}</p>
        <h1 className="font-serif text-5xl text-ink mb-10">{mode === "signin" ? "sign in." : "join."}</h1>
        <form onSubmit={onSubmit} className="space-y-5">
          {mode === "signup" && (
            <div>
              <Label className="label-mono">name</Label>
              <Input value={displayName} onChange={(e) => setDisplayName(e.target.value)} maxLength={60}
                className="bg-paper border-rule mt-2 font-serif" required />
            </div>
          )}
          <div>
            <Label className="label-mono">email</Label>
            <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} maxLength={255}
              className="bg-paper border-rule mt-2 font-mono text-sm" required />
          </div>
          <div>
            <Label className="label-mono">password</Label>
            <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} minLength={8} maxLength={128}
              className="bg-paper border-rule mt-2 font-mono text-sm" required />
          </div>
          <Button type="submit" disabled={loading} className="w-full font-mono text-xs uppercase tracking-widest">
            {loading ? "…" : mode === "signin" ? "Sign in" : "Create account"}
          </Button>
        </form>
        <div className="my-6 flex items-center gap-3">
          <span className="flex-1 h-px bg-rule" />
          <span className="label-mono">or</span>
          <span className="flex-1 h-px bg-rule" />
        </div>
        <Button
          type="button"
          onClick={onGoogle}
          disabled={loading}
          variant="outline"
          className="w-full font-mono text-xs uppercase tracking-widest border-rule bg-paper hover:bg-paper/70 gap-3"
        >
          <svg width="16" height="16" viewBox="0 0 48 48" aria-hidden="true">
            <path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.4 29.3 35.5 24 35.5c-6.4 0-11.5-5.1-11.5-11.5S17.6 12.5 24 12.5c2.9 0 5.6 1.1 7.6 2.9l5.7-5.7C33.6 6.3 29 4.5 24 4.5 13.2 4.5 4.5 13.2 4.5 24S13.2 43.5 24 43.5 43.5 34.8 43.5 24c0-1.2-.1-2.4-.4-3.5z"/>
            <path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 16 19 13 24 13c2.9 0 5.6 1.1 7.6 2.9l5.7-5.7C33.6 6.3 29 4.5 24 4.5 16.4 4.5 9.8 8.7 6.3 14.7z"/>
            <path fill="#4CAF50" d="M24 43.5c5 0 9.6-1.7 13.1-4.6l-6-5.1c-2 1.4-4.5 2.2-7.1 2.2-5.3 0-9.7-3.1-11.3-7.5l-6.5 5C9.7 39.2 16.3 43.5 24 43.5z"/>
            <path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4-4.1 5.3l6 5.1c-.4.4 6.6-4.8 6.6-14.4 0-1.2-.1-2.4-.4-3.5z"/>
          </svg>
          Continue with Google
        </Button>
        <p className="mt-6 font-serif italic text-ink-soft">
          {mode === "signin" ? (
            <>new here?{" "}<button onClick={() => setMode("signup")} className="underline underline-offset-4 hover:text-primary">create an account</button></>
          ) : (
            <>already arrived?{" "}<button onClick={() => setMode("signin")} className="underline underline-offset-4 hover:text-primary">sign in</button></>
          )}
        </p>
        <p className="mt-2"><Link to="/" className="label-mono hover:text-primary">← back home</Link></p>
      </section>
    </Layout>
  );
};

export default Auth;