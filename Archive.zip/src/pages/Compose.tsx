import { useState } from "react";
import { useNavigate, Navigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import Layout from "@/components/poet/Layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { z } from "zod";

const schema = z.object({
  title: z.string().trim().min(1, "Title required").max(200),
  content: z.string().trim().min(1, "Write something").max(20000),
  excerpt: z.string().trim().max(500).optional(),
});

const Compose = () => {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [excerpt, setExcerpt] = useState("");
  const [busy, setBusy] = useState(false);

  if (!loading && !user) return <Navigate to="/auth" replace />;
  if (loading) return null;

  const submit = async (published: boolean) => {
    const parsed = schema.safeParse({ title, content, excerpt: excerpt || undefined });
    if (!parsed.success) return toast.error(parsed.error.issues[0].message);
    setBusy(true);
    const { data, error } = await supabase.from("poems").insert({
      title: parsed.data.title,
      content: parsed.data.content,
      excerpt: parsed.data.excerpt ?? null,
      author_id: user!.id,
      published,
    }).select("id").single();
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success(published ? "Piece posted." : "Draft saved.");
    if (published) navigate(`/poems/${data.id}`);
    else { setTitle(""); setContent(""); setExcerpt(""); }
  };

  return (
    <Layout>
      <section className="max-w-3xl mx-auto px-6 pt-16 pb-24">
        <p className="label-mono mb-6">— new piece</p>
        <h1 className="font-serif text-5xl text-ink mb-10">write.</h1>
        <form onSubmit={(e) => { e.preventDefault(); submit(true); }} className="space-y-5">
          <div>
            <Label className="label-mono">title</Label>
            <Input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              maxLength={200}
              className="bg-paper border-rule mt-2 font-serif text-2xl h-auto py-3"
              required
            />
          </div>
          <div>
            <Label className="label-mono">epigraph or excerpt (optional)</Label>
            <Input
              value={excerpt}
              onChange={(e) => setExcerpt(e.target.value)}
              maxLength={500}
              className="bg-paper border-rule mt-2 font-serif italic"
            />
          </div>
          <div>
            <Label className="label-mono">the piece</Label>
            <Textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              rows={16}
              maxLength={20000}
              className="bg-paper border-rule mt-2 font-serif text-lg leading-relaxed"
              required
            />
          </div>
          <div className="flex gap-3 pt-2">
            <Button type="submit" disabled={busy} className="font-mono text-xs uppercase tracking-widest">
              {busy ? "…" : "Publish"}
            </Button>
            <Button
              type="button"
              variant="outline"
              disabled={busy}
              onClick={() => submit(false)}
              className="font-mono text-xs uppercase tracking-widest border-rule"
            >
              Save draft
            </Button>
          </div>
        </form>
      </section>
    </Layout>
  );
};

export default Compose;
