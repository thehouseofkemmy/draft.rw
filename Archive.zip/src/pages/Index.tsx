import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import Layout from "@/components/poet/Layout";
import PoemCard from "@/components/poet/PoemCard";
import SubscribeForm from "@/components/poet/SubscribeForm";

type Poem = {
  id: string;
  title: string;
  content: string;
  excerpt: string | null;
  created_at: string;
  author_id: string | null;
  profiles: { display_name: string | null } | null;
};

const Index = () => {
  const [poems, setPoems] = useState<Poem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase
      .from("poems")
      .select("id, title, content, excerpt, created_at, author_id, profiles(display_name)")
      .eq("published", true)
      .order("created_at", { ascending: false })
      .then(({ data }) => {
        setPoems((data as Poem[]) ?? []);
        setLoading(false);
      });
  }, []);

  return (
    <Layout>
      <section className="max-w-3xl mx-auto px-6 pt-20 pb-16">
        <p className="label-mono mb-6">— drafts.rw</p>
        <h1 className="font-serif text-5xl md:text-7xl leading-[1.05] tracking-tight text-ink">
          quiet work,<br />
          <em className="text-primary">shared here</em>.
        </h1>
        <p className="poem-body mt-8 text-ink-soft max-w-xl">
          a shared space for pieces, fragments, and quiet attention. new work arrives when
          it is ready, not before.
        </p>

        <div className="mt-10">
          <p className="label-mono mb-3">letters by post</p>
          <SubscribeForm />
        </div>
      </section>

      <section className="max-w-3xl mx-auto px-6 pb-24">
        <div className="flex items-center gap-4 mb-12">
          <span className="label-mono">— recent pieces</span>
          <span className="flex-1 h-px bg-rule" />
          <span className="label-mono">{poems.length} pieces</span>
        </div>

        {loading ? (
          <p className="font-serif italic text-ink-soft">loading…</p>
        ) : poems.length === 0 ? (
          <p className="font-serif italic text-ink-soft">no pieces yet — soon.</p>
        ) : (
          <div className="space-y-12">
            {poems.map((p) => (
              <PoemCard
                key={p.id}
                id={p.id}
                title={p.title}
                content={p.content}
                excerpt={p.excerpt}
                created_at={p.created_at}
                author={p.author_id ? { id: p.author_id, display_name: p.profiles?.display_name ?? null } : undefined}
              />
            ))}
          </div>
        )}
      </section>
    </Layout>
  );
};

export default Index;
