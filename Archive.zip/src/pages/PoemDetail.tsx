import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import Layout from "@/components/poet/Layout";
import LikeButton from "@/components/poet/LikeButton";
import Comments from "@/components/poet/Comments";
import { format } from "date-fns";

type Poem = {
  id: string;
  title: string;
  content: string;
  created_at: string;
  author_id: string | null;
  profiles: { display_name: string | null } | null;
};

const PoemDetail = () => {
  const { id } = useParams();
  const [poem, setPoem] = useState<Poem | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!id) return;
    supabase
      .from("poems")
      .select("id, title, content, created_at, author_id, profiles(display_name)")
      .eq("id", id)
      .maybeSingle()
      .then(({ data }) => { setPoem(data as Poem | null); setLoading(false); });
  }, [id]);

  return (
    <Layout>
      <article className="max-w-2xl mx-auto px-6 pt-16 pb-12">
        <Link to="/" className="label-mono hover:text-primary">← back to pieces</Link>
        {loading ? (
          <p className="font-serif italic text-ink-soft mt-12">loading…</p>
        ) : !poem ? (
          <p className="font-serif italic text-ink-soft mt-12">not found.</p>
        ) : (
          <>
            <p className="label-mono mt-12 mb-4">{format(new Date(poem.created_at), "MMMM d, yyyy")}</p>
            <h1 className="font-serif text-4xl md:text-6xl text-ink leading-tight tracking-tight">{poem.title}</h1>
            {poem.author_id && (
              <Link
                to={`/poet/${poem.author_id}`}
                className="label-mono mt-2 inline-block hover:text-primary transition-colors"
              >
                {poem.profiles?.display_name ?? "unnamed poet"}
              </Link>
            )}
            <div className="my-10 h-px bg-rule" />
            <div className="poem-body">{poem.content}</div>
            <div className="mt-12 flex items-center gap-6 border-t border-rule pt-6">
              <LikeButton poemId={poem.id} />
            </div>
            <Comments poemId={poem.id} />
          </>
        )}
      </article>
    </Layout>
  );
};

export default PoemDetail;
