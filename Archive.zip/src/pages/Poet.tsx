import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import Layout from "@/components/poet/Layout";
import PoemCard from "@/components/poet/PoemCard";
import { format } from "date-fns";

type Profile = {
  id: string;
  display_name: string | null;
  bio: string | null;
  avatar_url: string | null;
  created_at: string;
};

type Poem = {
  id: string;
  title: string;
  content: string;
  excerpt: string | null;
  created_at: string;
};

const Poet = () => {
  const { id } = useParams<{ id: string }>();
  const [profile, setProfile] = useState<Profile | null>(null);
  const [poems, setPoems] = useState<Poem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!id) return;
    Promise.all([
      supabase.from("profiles").select("id, display_name, bio, avatar_url, created_at").eq("id", id).maybeSingle(),
      supabase.from("poems").select("id, title, content, excerpt, created_at")
        .eq("author_id", id).eq("published", true).order("created_at", { ascending: false }),
    ]).then(([{ data: p }, { data: poems }]) => {
      setProfile(p);
      setPoems(poems ?? []);
      setLoading(false);
    });
  }, [id]);

  return (
    <Layout>
      <section className="max-w-3xl mx-auto px-6 pt-16 pb-24">
        <Link to="/" className="label-mono hover:text-primary">← back to pieces</Link>

        {loading ? (
          <p className="font-serif italic text-ink-soft mt-12">loading…</p>
        ) : !profile ? (
          <p className="font-serif italic text-ink-soft mt-12">poet not found.</p>
        ) : (
          <>
            <div className="mt-12 flex items-start gap-6">
              {profile.avatar_url && (
                <img
                  src={profile.avatar_url}
                  alt={profile.display_name ?? "poet"}
                  className="w-16 h-16 rounded-full object-cover border border-rule"
                />
              )}
              <div>
                <h1 className="font-serif text-4xl text-ink">
                  {profile.display_name ?? "unnamed poet"}
                </h1>
                <p className="label-mono mt-1">
                  here since {format(new Date(profile.created_at), "MMMM yyyy")}
                </p>
                {profile.bio && (
                  <p className="poem-body text-ink-soft mt-4 max-w-prose">{profile.bio}</p>
                )}
              </div>
            </div>

            <div className="flex items-center gap-4 mt-16 mb-12">
              <span className="label-mono">— pieces</span>
              <span className="flex-1 h-px bg-rule" />
              <span className="label-mono">{poems.length}</span>
            </div>

            {poems.length === 0 ? (
              <p className="font-serif italic text-ink-soft">no published pieces yet.</p>
            ) : (
              <div className="space-y-12">
                {poems.map((p) => (
                  <PoemCard key={p.id} {...p} />
                ))}
              </div>
            )}
          </>
        )}
      </section>
    </Layout>
  );
};

export default Poet;
