import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import Layout from "@/components/poet/Layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { toast } from "sonner";

const Profile = () => {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const [displayName, setDisplayName] = useState("");
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => { if (!loading && !user) navigate("/auth"); }, [user, loading, navigate]);

  useEffect(() => {
    if (!user) return;
    supabase.from("profiles").select("display_name, avatar_url").eq("id", user.id).maybeSingle()
      .then(({ data }) => {
        setDisplayName(data?.display_name ?? "");
        setAvatarUrl(data?.avatar_url ?? null);
      });
  }, [user]);

  const upload = async (file: File) => {
    if (!user) return;
    if (file.size > 5 * 1024 * 1024) { toast.error("Max 5MB"); return; }
    setBusy(true);
    const ext = file.name.split(".").pop();
    const path = `${user.id}/avatar-${Date.now()}.${ext}`;
    const { error } = await supabase.storage.from("avatars").upload(path, file, { upsert: true });
    if (error) { setBusy(false); return toast.error(error.message); }
    const { data } = supabase.storage.from("avatars").getPublicUrl(path);
    setAvatarUrl(data.publicUrl);
    setBusy(false);
  };

  const save = async () => {
    if (!user) return;
    setBusy(true);
    const { error } = await supabase.from("profiles").upsert({
      id: user.id, display_name: displayName.slice(0, 60), avatar_url: avatarUrl,
    });
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success("Saved.");
  };

  if (!user) return null;

  return (
    <Layout>
      <section className="max-w-md mx-auto px-6 pt-20 pb-24">
        <p className="label-mono mb-6">— you</p>
        <h1 className="font-serif text-5xl text-ink mb-10">profile.</h1>
        <div className="flex items-center gap-4 mb-8">
          <Avatar className="h-20 w-20 border border-rule">
            <AvatarImage src={avatarUrl ?? undefined} />
            <AvatarFallback className="font-mono">{(displayName || "·").slice(0,2).toUpperCase()}</AvatarFallback>
          </Avatar>
          <label className="label-mono cursor-pointer hover:text-primary">
            change avatar
            <input type="file" accept="image/*" className="hidden" onChange={(e) => e.target.files?.[0] && upload(e.target.files[0])} />
          </label>
        </div>
        <div className="space-y-5">
          <div>
            <Label className="label-mono">display name</Label>
            <Input value={displayName} onChange={(e) => setDisplayName(e.target.value)} maxLength={60}
              className="bg-paper border-rule mt-2 font-serif" />
          </div>
          <Button onClick={save} disabled={busy} className="font-mono text-xs uppercase tracking-widest">
            {busy ? "…" : "Save"}
          </Button>
        </div>
      </section>
    </Layout>
  );
};

export default Profile;